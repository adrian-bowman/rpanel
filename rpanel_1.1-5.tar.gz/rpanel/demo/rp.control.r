p1 <- rp.control(title="First window", size=c(200, 50, 0, 0), background="navy")
p2 <- rp.control(title="Second window")
p3 <- rp.control(title="Third window", size=c(500, 200), extra=rnorm(10))
