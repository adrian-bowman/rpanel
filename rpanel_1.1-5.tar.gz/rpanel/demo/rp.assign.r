panel <- rp.control()
rp.assign(panel, b=1, d=10)
print(rp()$panel$b)
print(rp()$panel$d)
